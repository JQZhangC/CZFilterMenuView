//
//  CZFilterMenuTableViewCell.m
//  CZFilterMenuView
//
//  Created by MC on 2020/9/9.
//  Copyright © 2020 CZ. All rights reserved.
//

#import "CZFilterMenuTableViewCell.h"

@implementation CZFilterMenuTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle = UITableViewCellSeparatorStyleNone;
}


@end
