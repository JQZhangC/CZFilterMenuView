//
//  CZFilterMenuTableViewCell.h
//  CZFilterMenuView
//
//  Created by MC on 2020/9/9.
//  Copyright © 2020 CZ. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CZFilterMenuTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end

NS_ASSUME_NONNULL_END
