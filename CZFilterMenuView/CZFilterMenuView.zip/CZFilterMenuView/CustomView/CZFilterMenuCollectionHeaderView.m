//
//  CZFilterMenuCollectionHeaderView.m
//  CZFilterMenuView
//
//  Created by CZ on 2020/10/28.
//  Copyright © 2020 CZ. All rights reserved.
//

#import "CZFilterMenuCollectionHeaderView.h"

@implementation CZFilterMenuCollectionHeaderView

- (void)awakeFromNib {
    [super awakeFromNib];
    
}

@end
